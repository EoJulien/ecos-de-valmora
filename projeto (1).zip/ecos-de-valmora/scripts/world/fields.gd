extends Node3D
## Campos de Valmora: planície a leste, sul e oeste da vila, com ruínas antigas,
## uma colina com mirante (cristal decorativo), rochas e árvores esparsas.

const B = preload("res://scripts/world/builder.gd")
const RUINS := Vector3(38.0, 0.0, -10.0)
const SAND := Color(0.72, 0.62, 0.45)
const STONE := Color(0.6, 0.6, 0.62)
const PATHS := [
    [Vector3(22, 0, 0), Vector3(32, 0, -6)],
    [Vector3(0, 0, 18), Vector3(0, 0, 38)],
    [Vector3(0, 0, 38), Vector3(34, 0, 38)],
]

var _crystal: MeshInstance3D


func _ready() -> void:
    for p in PATHS:
        B.path(self, p[0], p[1], 3.0, SAND)
    _ruins()
    _hill()
    _rocks()
    _scatter_trees()


func _process(delta: float) -> void:
    if _crystal:
        _crystal.rotate_y(delta)


func _ruins() -> void:
    B.solid_box(self, RUINS + Vector3(0.0, 0.2, 0.0), Vector3(16.0, 0.4, 16.0), STONE)
    # degrau de entrada (lado oeste, onde chega a trilha)
    B.solid_box(self, RUINS + Vector3(-8.6, 0.1, 4.0), Vector3(1.2, 0.2, 5.0), STONE)
    var heights := [4.0, 2.5, 4.0, 1.5, 4.0, 3.0, 4.0, 2.0]
    for i in 8:
        if i == 3 or i == 4:
            continue  # abertura da entrada
        var a := TAU * float(i) / 8.0
        var h: float = heights[i]
        B.solid_cylinder(self, RUINS + Vector3(cos(a) * 6.0, 0.4 + h * 0.5, sin(a) * 6.0), 0.55, h, STONE)
    B.solid_box(self, RUINS + Vector3(0.0, 1.0, 0.0), Vector3(2.0, 1.2, 2.0), Color(0.5, 0.5, 0.54))
    B.solid_box(self, RUINS + Vector3(7.5, 1.4, -2.0), Vector3(0.6, 2.0, 6.0), STONE)
    B.solid_box(self, RUINS + Vector3(0.0, 1.2, -7.5), Vector3(8.0, 1.6, 0.6), STONE)
    B.solid_box(self, RUINS + Vector3(-3.0, 0.8, 5.0), Vector3(1.4, 0.8, 1.0), Color(0.5, 0.5, 0.54), Vector3(0.0, 25.0, 0.0))


func _hill() -> void:
    # rampa suave de 10 graus subindo para leste, até um platô com pedras e o cristal
    B.solid_box(self, Vector3(45.0, 1.3, 36.0), Vector3(20.0, 1.0, 14.0), Color(0.4, 0.62, 0.3), Vector3(0.0, 0.0, 10.0))
    B.solid_box(self, Vector3(57.0, 3.3, 36.0), Vector3(6.0, 0.4, 12.0), Color(0.45, 0.66, 0.34))
    B.solid_box(self, Vector3(58.0, 4.4, 32.0), Vector3(0.8, 1.8, 0.8), STONE)
    B.solid_box(self, Vector3(58.0, 4.4, 40.0), Vector3(0.8, 1.8, 0.8), STONE)
    var mesh := SphereMesh.new()
    mesh.radius = 0.6
    mesh.height = 2.2
    mesh.radial_segments = 4
    mesh.rings = 2
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.4, 0.9, 1.0)
    m.emission_enabled = true
    m.emission = Color(0.2, 0.8, 1.0)
    m.emission_energy_multiplier = 1.5
    _crystal = MeshInstance3D.new()
    _crystal.mesh = mesh
    _crystal.material_override = m
    _crystal.position = Vector3(57.5, 4.9, 36.0)
    add_child(_crystal)
    var light := OmniLight3D.new()
    light.light_color = Color(0.4, 0.9, 1.0)
    light.omni_range = 10.0
    light.light_energy = 1.2
    light.position = Vector3(57.5, 5.2, 36.0)
    add_child(light)


func _random_field_point(rng: RandomNumberGenerator) -> Vector3:
    var r := rng.randi_range(0, 2)
    if r == 0:
        return Vector3(rng.randf_range(-58.0, 58.0), 0.0, rng.randf_range(20.0, 58.0))
    elif r == 1:
        return Vector3(rng.randf_range(24.0, 58.0), 0.0, rng.randf_range(-58.0, 20.0))
    return Vector3(rng.randf_range(-58.0, -24.0), 0.0, rng.randf_range(-20.0, 20.0))


func _spot_ok(p: Vector3, margin: float) -> bool:
    if p.z < -20.0 and p.x < 31.0:
        return false  # área da floresta
    if Vector2(p.x - RUINS.x, p.z - RUINS.z).length() < 13.0:
        return false
    if p.x > 31.0 and p.z > 26.0 and p.z < 46.0:
        return false  # colina
    for pa in PATHS:
        if B.dist_to_segment(p, pa[0], pa[1]) < 3.0 + margin:
            return false
    return true


func _rocks() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    var n := 0
    var tries := 0
    while n < 14 and tries < 300:
        tries += 1
        var p := _random_field_point(rng)
        if not _spot_ok(p, 2.0):
            continue
        var s := Vector3(rng.randf_range(1.0, 2.4), rng.randf_range(0.8, 1.8), rng.randf_range(1.0, 2.4))
        var rot := Vector3(rng.randf_range(-8.0, 8.0), rng.randf_range(0.0, 180.0), rng.randf_range(-8.0, 8.0))
        B.solid_box(self, Vector3(p.x, s.y * 0.35, p.z), s, Color(0.5, 0.5, 0.52), rot)
        n += 1


func _scatter_trees() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 9
    var spots: Array = []
    var tries := 0
    while spots.size() < 28 and tries < 600:
        tries += 1
        var p := _random_field_point(rng)
        if _spot_ok(p, 2.5):
            spots.append(p)
    B.trees(self, spots, 33)
