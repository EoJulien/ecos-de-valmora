extends Node3D
## Vila de Arvendal: praça com poço, casas, cercas, portal norte e estradas.
## Ocupa x de -22 a 22 e z de -20 a 18. A saída norte leva ao Bosque; leste e sul, aos Campos.

const B = preload("res://scripts/world/builder.gd")
const SAND := Color(0.72, 0.62, 0.45)
const WOOD := Color(0.5, 0.35, 0.2)
const STONE := Color(0.58, 0.58, 0.6)


func _ready() -> void:
    _plaza_and_roads()
    _fences()
    _gate()
    _houses()
    _well()
    var spots: Array = [
        Vector3(-6, 0, -15), Vector3(7, 0, -15), Vector3(-20, 0, -3), Vector3(20, 0, -15),
        Vector3(-6, 0, 16), Vector3(7, 0, 16), Vector3(-20, 0, 16), Vector3(20, 0, 16),
    ]
    B.trees(self, spots, 11)


func _plaza_and_roads() -> void:
    B.deco_cylinder(self, Vector3(0.0, 0.05, 0.0), 7.0, 0.1, SAND)
    B.deco_box(self, Vector3(0.0, 0.045, -11.0), Vector3(4.0, 0.09, 20.0), SAND)
    B.deco_box(self, Vector3(0.0, 0.045, 12.5), Vector3(4.0, 0.09, 12.0), SAND)
    B.deco_box(self, Vector3(14.0, 0.045, 0.0), Vector3(16.0, 0.09, 3.0), SAND)


func _fences() -> void:
    var h := 0.9
    # sul (abertura no meio)
    B.solid_box(self, Vector3(-13.0, h * 0.5, 18.0), Vector3(18.0, h, 0.15), WOOD)
    B.solid_box(self, Vector3(13.0, h * 0.5, 18.0), Vector3(18.0, h, 0.15), WOOD)
    # norte (abertura no meio)
    B.solid_box(self, Vector3(-12.5, h * 0.5, -18.0), Vector3(19.0, h, 0.15), WOOD)
    B.solid_box(self, Vector3(12.5, h * 0.5, -18.0), Vector3(19.0, h, 0.15), WOOD)
    # oeste (fechado)
    B.solid_box(self, Vector3(-22.0, h * 0.5, 0.0), Vector3(0.15, h, 36.0), WOOD)
    # leste (abertura no meio)
    B.solid_box(self, Vector3(22.0, h * 0.5, -10.5), Vector3(0.15, h, 15.0), WOOD)
    B.solid_box(self, Vector3(22.0, h * 0.5, 10.5), Vector3(0.15, h, 15.0), WOOD)


func _gate() -> void:
    B.solid_box(self, Vector3(-3.4, 1.5, -18.0), Vector3(0.6, 3.0, 0.6), WOOD)
    B.solid_box(self, Vector3(3.4, 1.5, -18.0), Vector3(0.6, 3.0, 0.6), WOOD)
    B.deco_box(self, Vector3(0.0, 3.2, -18.0), Vector3(7.4, 0.4, 0.6), WOOD)


func _houses() -> void:
    _house(Vector3(-14, 0, -10), Color(0.88, 0.8, 0.66), Color(0.65, 0.25, 0.2))
    _house(Vector3(14, 0, -10), Color(0.9, 0.85, 0.7), Color(0.3, 0.4, 0.55))
    _house(Vector3(-16, 0, 6), Color(0.85, 0.75, 0.6), Color(0.75, 0.4, 0.2))
    _house(Vector3(16, 0, 6), Color(0.9, 0.82, 0.68), Color(0.65, 0.25, 0.2))
    _house(Vector3(-12, 0, 13), Color(0.86, 0.78, 0.64), Color(0.3, 0.4, 0.55))
    _house(Vector3(12, 0, 13), Color(0.88, 0.8, 0.66), Color(0.75, 0.4, 0.2))


## A porta (lado +Z da casa) sempre fica virada para o centro da praça.
func _house(pos: Vector3, wall: Color, roof: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    root.rotation.y = atan2(-pos.x, -pos.z)
    add_child(root)
    B.solid_box(root, Vector3(0.0, 1.6, 0.0), Vector3(6.0, 3.2, 5.0), wall)
    var prism := PrismMesh.new()
    prism.size = Vector3(7.0, 2.2, 5.6)
    B.add_mesh(root, prism, roof, Vector3(0.0, 4.3, 0.0))
    B.deco_box(root, Vector3(0.0, 1.1, 2.53), Vector3(1.2, 2.2, 0.1), Color(0.35, 0.22, 0.12))
    B.deco_box(root, Vector3(-1.9, 1.8, 2.53), Vector3(0.9, 0.9, 0.1), Color(0.6, 0.8, 0.9))
    B.deco_box(root, Vector3(1.9, 1.8, 2.53), Vector3(0.9, 0.9, 0.1), Color(0.6, 0.8, 0.9))
    B.deco_box(root, Vector3(1.8, 5.2, -1.0), Vector3(0.7, 1.6, 0.7), STONE)


func _well() -> void:
    B.solid_cylinder(self, Vector3(0.0, 0.5, 0.0), 1.4, 1.0, STONE)
    B.deco_cylinder(self, Vector3(0.0, 0.98, 0.0), 1.0, 0.06, Color(0.25, 0.5, 0.8))
    B.deco_box(self, Vector3(-1.2, 2.0, 0.0), Vector3(0.15, 2.0, 0.15), WOOD)
    B.deco_box(self, Vector3(1.2, 2.0, 0.0), Vector3(0.15, 2.0, 0.15), WOOD)
    var roof := PrismMesh.new()
    roof.size = Vector3(3.2, 1.0, 3.0)
    B.add_mesh(self, roof, Color(0.65, 0.25, 0.2), Vector3(0.0, 3.5, 0.0))
