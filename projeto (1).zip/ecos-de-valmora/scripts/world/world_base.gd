extends Node3D
## Base do mundo: chão, muralhas de rocha nas bordas e montanhas ao fundo.

const B = preload("res://scripts/world/builder.gd")


func _ready() -> void:
    B.solid_box(self, Vector3(0.0, -0.5, 0.0), Vector3(124.0, 1.0, 124.0), Color(0.35, 0.65, 0.3))
    var rock := Color(0.42, 0.4, 0.42)
    B.solid_box(self, Vector3(0.0, 7.0, -61.0), Vector3(126.0, 14.0, 2.0), rock)
    B.solid_box(self, Vector3(0.0, 7.0, 61.0), Vector3(126.0, 14.0, 2.0), rock)
    B.solid_box(self, Vector3(-61.0, 7.0, 0.0), Vector3(2.0, 14.0, 126.0), rock)
    B.solid_box(self, Vector3(61.0, 7.0, 0.0), Vector3(2.0, 14.0, 126.0), rock)

    var rng := RandomNumberGenerator.new()
    rng.seed = 3
    for i in 14:
        var a := TAU * float(i) / 14.0 + rng.randf_range(-0.15, 0.15)
        var r := rng.randf_range(95.0, 110.0)
        var h := rng.randf_range(26.0, 45.0)
        var rad := rng.randf_range(20.0, 32.0)
        var c := Color(0.42, 0.48, 0.58).lerp(Color(0.6, 0.65, 0.75), rng.randf())
        B.deco_cone(self, Vector3(cos(a) * r, h * 0.5, sin(a) * r), rad, h, c)
