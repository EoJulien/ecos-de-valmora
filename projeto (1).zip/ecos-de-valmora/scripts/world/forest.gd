extends Node3D
## Bosque dos Antigos: floresta ao norte da vila (z menor que -20), com trilha,
## clareira, a Grande Árvore Antiga, pedras e troncos caídos para pular.

const B = preload("res://scripts/world/builder.gd")
const CLEARING := Vector3(-10.0, 0.0, -40.0)
const PATH_A := Vector3(0.0, 0.0, -21.0)
const BARK := Color(0.38, 0.26, 0.15)
const STONE := Color(0.55, 0.55, 0.58)
const LOGS := [
    [Vector3(-4, 0, -28), 20.0],
    [Vector3(9, 0, -34), 75.0],
    [Vector3(-24, 0, -31), 100.0],
    [Vector3(-30, 0, -48), 35.0],
    [Vector3(12, 0, -50), 120.0],
]


func _ready() -> void:
    B.deco_box(self, Vector3(-11.0, 0.03, -40.0), Vector3(82.0, 0.06, 36.0), Color(0.2, 0.46, 0.22))
    B.deco_cylinder(self, Vector3(CLEARING.x, 0.04, CLEARING.z), 9.0, 0.08, Color(0.42, 0.7, 0.3))
    B.path(self, PATH_A, CLEARING, 3.2, Color(0.72, 0.62, 0.45))
    _great_tree()
    _stones()
    _logs()
    _forest_trees()


func _great_tree() -> void:
    B.solid_cylinder(self, Vector3(CLEARING.x, 6.0, CLEARING.z), 2.2, 12.0, BARK)
    var canopy := SphereMesh.new()
    canopy.radius = 8.0
    canopy.height = 10.0
    canopy.radial_segments = 12
    canopy.rings = 6
    B.add_mesh(self, canopy, Color(0.12, 0.42, 0.18), Vector3(CLEARING.x, 14.0, CLEARING.z))
    var shape := SphereShape3D.new()
    shape.radius = 5.0
    B.static_body(self, Vector3(CLEARING.x, 13.0, CLEARING.z), Vector3.ZERO, shape, 2)
    for i in 5:
        var a := TAU * float(i) / 5.0
        B.solid_box(self, Vector3(CLEARING.x + cos(a) * 2.6, 0.35, CLEARING.z + sin(a) * 2.6),
            Vector3(2.6, 0.7, 0.7), BARK, Vector3(0.0, -rad_to_deg(a), 0.0))


func _stones() -> void:
    for i in 6:
        var a := TAU * float(i) / 6.0 + 0.3
        B.solid_box(self, Vector3(CLEARING.x + cos(a) * 6.5, 0.9, CLEARING.z + sin(a) * 6.5),
            Vector3(0.9, 1.8, 0.7), STONE, Vector3(0.0, -rad_to_deg(a), 0.0))


func _logs() -> void:
    for l in LOGS:
        var p: Vector3 = l[0]
        B.solid_cylinder(self, Vector3(p.x, 0.6, p.z), 0.6, 5.0, BARK, Vector3(0.0, l[1], 90.0))


func _near_log(p: Vector3) -> bool:
    for l in LOGS:
        var q: Vector3 = l[0]
        if Vector2(p.x - q.x, p.z - q.z).length() < 4.0:
            return true
    return false


func _forest_trees() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    var spots: Array = []
    var x := -50.0
    while x <= 28.0:
        var z := -57.0
        while z <= -23.0:
            var p := Vector3(x + rng.randf_range(-1.7, 1.7), 0.0, z + rng.randf_range(-1.7, 1.7))
            var from_clearing := Vector2(p.x - CLEARING.x, p.z - CLEARING.z).length()
            if from_clearing > 10.5 and B.dist_to_segment(p, PATH_A, CLEARING) > 3.8 and not _near_log(p):
                spots.append(p)
            z += 5.0
        x += 5.0
    B.trees(self, spots, 21)
