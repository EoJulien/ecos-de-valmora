extends RefCounted
## Funções utilitárias para montar o cenário por código (estilo low-poly).
## Camadas de colisão: 1 = mundo (jogador colide), 2 = só câmera (copas de árvores).

static var _mats := {}


static func mat(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _mats.has(key):
        var m := StandardMaterial3D.new()
        m.albedo_color = color
        _mats[key] = m
    return _mats[key]


static func add_mesh(parent: Node, mesh: Mesh, color: Color, pos: Vector3, rot_deg := Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat(color)
    mi.position = pos
    mi.rotation_degrees = rot_deg
    parent.add_child(mi)
    return mi


static func static_body(parent: Node, pos: Vector3, rot_deg: Vector3, shape: Shape3D, layer: int) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees = rot_deg
    body.collision_layer = layer
    body.collision_mask = 0
    var cs := CollisionShape3D.new()
    cs.shape = shape
    body.add_child(cs)
    parent.add_child(body)
    return body


static func deco_box(parent: Node, pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO) -> MeshInstance3D:
    var bm := BoxMesh.new()
    bm.size = size
    return add_mesh(parent, bm, color, pos, rot_deg)


static func deco_cylinder(parent: Node, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = 14
    cm.rings = 1
    return add_mesh(parent, cm, color, pos)


static func deco_cone(parent: Node, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var cm := CylinderMesh.new()
    cm.top_radius = 0.0
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = 6
    cm.rings = 1
    return add_mesh(parent, cm, color, pos)


static func solid_box(parent: Node, pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO) -> StaticBody3D:
    var shape := BoxShape3D.new()
    shape.size = size
    var body := static_body(parent, pos, rot_deg, shape, 1)
    var bm := BoxMesh.new()
    bm.size = size
    add_mesh(body, bm, color, Vector3.ZERO)
    return body


static func solid_cylinder(parent: Node, pos: Vector3, radius: float, height: float, color: Color, rot_deg := Vector3.ZERO) -> StaticBody3D:
    var shape := CylinderShape3D.new()
    shape.radius = radius
    shape.height = height
    var body := static_body(parent, pos, rot_deg, shape, 1)
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = 10
    cm.rings = 1
    add_mesh(body, cm, color, Vector3.ZERO)
    return body


## Trilha de terra entre dois pontos (só visual, o chão já tem colisão).
static func path(parent: Node, a: Vector3, b: Vector3, width: float, color: Color) -> void:
    var d := b - a
    d.y = 0.0
    var mid := (a + b) * 0.5
    var yaw := rad_to_deg(atan2(d.x, d.z))
    deco_box(parent, Vector3(mid.x, 0.045, mid.z), Vector3(width, 0.09, d.length()), color, Vector3(0.0, yaw, 0.0))


## Distância (no plano XZ) de um ponto até um segmento.
static func dist_to_segment(p: Vector3, a: Vector3, b: Vector3) -> float:
    var ab := Vector2(b.x - a.x, b.z - a.z)
    var ap := Vector2(p.x - a.x, p.z - a.z)
    var t := clampf(ap.dot(ab) / ab.length_squared(), 0.0, 1.0)
    return (ap - ab * t).length()


static func multimesh(parent: Node, mesh: Mesh, color: Color, xforms: Array[Transform3D]) -> void:
    if xforms.is_empty():
        return
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = xforms.size()
    for i in xforms.size():
        mm.set_instance_transform(i, xforms[i])
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    mmi.material_override = mat(color)
    parent.add_child(mmi)


## Árvores baratas: todos os troncos num MultiMesh e todas as copas em outro
## (2 chamadas de desenho para qualquer quantidade). Tronco colide com o jogador;
## a copa colide só com a câmera.
static func trees(parent: Node, spots: Array, seed_value: int = 1) -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var trunk := CylinderMesh.new()
    trunk.top_radius = 0.22
    trunk.bottom_radius = 0.3
    trunk.height = 3.0
    trunk.radial_segments = 6
    trunk.rings = 1
    var canopy := CylinderMesh.new()
    canopy.top_radius = 0.0
    canopy.bottom_radius = 1.6
    canopy.height = 4.0
    canopy.radial_segments = 7
    canopy.rings = 1
    var tx: Array[Transform3D] = []
    var cx: Array[Transform3D] = []
    for p in spots:
        var s := rng.randf_range(0.8, 1.4)
        var yaw := rng.randf_range(0.0, TAU)
        var b := Basis(Vector3.UP, yaw).scaled(Vector3(s, s, s))
        tx.append(Transform3D(b, Vector3(p.x, 1.5 * s, p.z)))
        cx.append(Transform3D(b, Vector3(p.x, 4.6 * s, p.z)))
        var ts := CylinderShape3D.new()
        ts.radius = 0.3 * s
        ts.height = 3.0 * s
        static_body(parent, Vector3(p.x, 1.5 * s, p.z), Vector3.ZERO, ts, 1)
        var cs := CylinderShape3D.new()
        cs.radius = 1.2 * s
        cs.height = 3.2 * s
        static_body(parent, Vector3(p.x, 4.4 * s, p.z), Vector3.ZERO, cs, 2)
    multimesh(parent, trunk, Color(0.4, 0.27, 0.15), tx)
    multimesh(parent, canopy, Color(0.15, 0.5, 0.2), cx)
