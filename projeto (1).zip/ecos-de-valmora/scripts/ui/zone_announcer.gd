extends Label
## Mostra o nome da região quando o jogador entra nela.

var player: Node3D
var _current := ""
var _tween: Tween


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    offset_top = 70.0
    offset_bottom = 130.0
    add_theme_font_size_override("font_size", 44)
    add_theme_color_override("font_color", Color(1.0, 0.9, 0.55))
    add_theme_color_override("font_outline_color", Color.BLACK)
    add_theme_constant_override("outline_size", 8)
    modulate.a = 0.0


func _zone_at(p: Vector3) -> String:
    if p.x > -22.0 and p.x < 22.0 and p.z > -20.0 and p.z < 18.0:
        return "Vila de Arvendal"
    if p.z <= -20.0 and p.x < 30.0:
        return "Bosque dos Antigos"
    return "Campos de Valmora"


func _process(_delta: float) -> void:
    if player == null:
        return
    var z := _zone_at(player.global_position)
    if z != _current:
        _current = z
        _announce(z)


func _announce(zone_name: String) -> void:
    text = zone_name
    if _tween:
        _tween.kill()
    modulate.a = 0.0
    _tween = create_tween()
    _tween.tween_property(self, "modulate:a", 1.0, 0.6)
    _tween.tween_interval(2.2)
    _tween.tween_property(self, "modulate:a", 0.0, 1.0)
