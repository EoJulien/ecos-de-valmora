extends CharacterBody3D
## Protagonista (placeholder low-poly feito de primitivas; troque pelo modelo final depois).
## Anda, corre (conforme a força do analógico) e pula. Movimento relativo à câmera.

const WALK_SPEED := 3.0
const RUN_SPEED := 7.0
const JUMP_VELOCITY := 8.0
const GRAVITY := 22.0
const ACCEL := 30.0
const TURN_SPEED := 12.0

var camera_rig: Node3D
var _model: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _anim_t := 0.0


func _ready() -> void:
    var col := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.7
    col.shape = cap
    col.position.y = 0.85
    add_child(col)
    _build_model()


func _part(mesh: Mesh, color: Color, pos: Vector3, parent: Node3D) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    mi.material_override = m
    mi.position = pos
    parent.add_child(mi)


func _make_leg(x: float) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = Vector3(x, 0.7, 0.0)
    _model.add_child(pivot)
    var bm := BoxMesh.new()
    bm.size = Vector3(0.22, 0.7, 0.25)
    _part(bm, Color(0.35, 0.25, 0.2), Vector3(0.0, -0.35, 0.0), pivot)
    return pivot


func _build_model() -> void:
    _model = Node3D.new()
    add_child(_model)
    var torso := BoxMesh.new()
    torso.size = Vector3(0.6, 0.7, 0.35)
    _part(torso, Color(0.2, 0.45, 0.75), Vector3(0.0, 1.05, 0.0), _model)
    var head := SphereMesh.new()
    head.radius = 0.25
    head.height = 0.5
    _part(head, Color(0.95, 0.8, 0.65), Vector3(0.0, 1.6, 0.0), _model)
    var hair := BoxMesh.new()
    hair.size = Vector3(0.5, 0.18, 0.5)
    _part(hair, Color(0.55, 0.25, 0.15), Vector3(0.0, 1.78, 0.02), _model)
    var nose := BoxMesh.new()
    nose.size = Vector3(0.08, 0.08, 0.12)
    _part(nose, Color(0.9, 0.7, 0.55), Vector3(0.0, 1.6, -0.27), _model)  # frente = -Z
    _leg_l = _make_leg(-0.15)
    _leg_r = _make_leg(0.15)


func _physics_process(delta: float) -> void:
    var m := Controls.get_move()
    var mag := minf(m.length(), 1.0)
    var yaw := 0.0
    if camera_rig:
        yaw = camera_rig.yaw
    var dir := Vector3(m.x, 0.0, m.y).rotated(Vector3.UP, yaw)

    var target_h := Vector3.ZERO
    if mag > 0.1:
        var speed := lerpf(WALK_SPEED, RUN_SPEED, smoothstep(0.5, 0.9, mag))
        target_h = dir.normalized() * speed
        var want := atan2(-dir.x, -dir.z)
        _model.rotation.y = lerp_angle(_model.rotation.y, want, minf(1.0, TURN_SPEED * delta))

    var h := Vector3(velocity.x, 0.0, velocity.z).move_toward(target_h, ACCEL * delta)
    velocity.x = h.x
    velocity.z = h.z

    var jump := Controls.consume_jump()
    velocity.y -= GRAVITY * delta
    if is_on_floor() and jump:
        velocity.y = JUMP_VELOCITY

    move_and_slide()
    _animate(delta)

    if global_position.y < -20.0:
        global_position = Vector3(0.0, 2.0, 12.0)
        velocity = Vector3.ZERO


func _animate(delta: float) -> void:
    var sp := Vector3(velocity.x, 0.0, velocity.z).length()
    if is_on_floor() and sp > 0.2:
        _anim_t += delta * sp * 1.8
        var amp := clampf(sp / RUN_SPEED, 0.3, 1.0) * 0.9
        _leg_l.rotation.x = sin(_anim_t) * amp
        _leg_r.rotation.x = -sin(_anim_t) * amp
    elif not is_on_floor():
        _leg_l.rotation.x = lerpf(_leg_l.rotation.x, 0.5, 10.0 * delta)
        _leg_r.rotation.x = lerpf(_leg_r.rotation.x, -0.5, 10.0 * delta)
    else:
        _leg_l.rotation.x = lerpf(_leg_l.rotation.x, 0.0, 10.0 * delta)
        _leg_r.rotation.x = lerpf(_leg_r.rotation.x, 0.0, 10.0 * delta)
