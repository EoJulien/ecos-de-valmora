extends Node3D
## Cena principal: ambiente, regiões do mundo, jogador, câmera e interface.

const SPAWN := Vector3(0.0, 1.0, 12.0)
const REGIONS := [
    preload("res://scripts/world/world_base.gd"),
    preload("res://scripts/world/village.gd"),
    preload("res://scripts/world/forest.gd"),
    preload("res://scripts/world/fields.gd"),
]

var _fps_label: Label


func _ready() -> void:
    _build_environment()
    for region_script in REGIONS:
        add_child(region_script.new())

    var player = preload("res://scripts/player.gd").new()
    add_child(player)
    player.position = SPAWN

    var rig = preload("res://scripts/camera_rig.gd").new()
    add_child(rig)
    rig.target = player
    rig.global_position = player.position + Vector3(0.0, 1.6, 0.0)
    player.camera_rig = rig
    rig.arm.add_excluded_object(player.get_rid())

    _build_ui(player)


func _process(_delta: float) -> void:
    _fps_label.text = "FPS: %d" % Engine.get_frames_per_second()


func _build_environment() -> void:
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.25, 0.5, 0.85)
    sky_mat.sky_horizon_color = Color(0.7, 0.82, 0.95)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.fog_enabled = true
    env.fog_light_color = Color(0.7, 0.82, 0.95)
    env.fog_density = 0.005
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
    sun.shadow_enabled = false  # sombras desligadas: barato para celulares modestos
    add_child(sun)


func _build_ui(player: Node3D) -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    layer.add_child(preload("res://scripts/touch_controls.gd").new())
    var zone = preload("res://scripts/ui/zone_announcer.gd").new()
    zone.player = player
    layer.add_child(zone)
    _fps_label = Label.new()
    _fps_label.position = Vector2(16.0, 12.0)
    _fps_label.add_theme_color_override("font_outline_color", Color.BLACK)
    _fps_label.add_theme_constant_override("outline_size", 4)
    layer.add_child(_fps_label)
