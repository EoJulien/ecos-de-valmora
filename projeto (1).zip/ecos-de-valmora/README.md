# Ecos de Valmora — Etapa 2 (vila, floresta e campos)

## Estrutura
- project.godot, export_presets.cfg, icon.svg
- scenes/main.tscn            -> cena principal (só carrega scripts/main.gd)
- scripts/main.gd             -> monta ambiente, regiões, jogador, câmera e UI
- scripts/controls.gd         -> autoload "Controls": toque + teclado
- scripts/touch_controls.gd   -> analógico virtual, câmera por arrasto, botão Pular
- scripts/camera_rig.gd       -> câmera 3ª pessoa (SpringArm; copas de árvore empurram a câmera)
- scripts/player.gd           -> protagonista placeholder
- scripts/world/builder.gd    -> funções para montar cenário (caixas, cilindros, árvores em MultiMesh)
- scripts/world/world_base.gd -> chão, muralhas, montanhas
- scripts/world/village.gd    -> Vila de Arvendal
- scripts/world/forest.gd     -> Bosque dos Antigos
- scripts/world/fields.gd     -> Campos de Valmora (ruínas, colina com mirante)
- scripts/ui/zone_announcer.gd-> nome da região ao entrar

## Teste no PC
F5. WASD/setas, Shift = andar devagar, Espaço = pular, Q/E = girar câmera.
