# Ecos de Valmora — Etapa 1 (personagem, câmera, movimentação)

## Estrutura
- project.godot           -> configuração (Godot 4.3+, renderer Compatibilidade, tela horizontal)
- scenes/main.tscn        -> cena principal (só carrega scripts/main.gd)
- scripts/controls.gd     -> autoload "Controls": estado de entrada (toque + teclado)
- scripts/touch_controls.gd -> analógico virtual, arrasto de câmera, botão Pular (multitouch)
- scripts/camera_rig.gd   -> câmera em 3ª pessoa com SpringArm3D
- scripts/player.gd       -> protagonista placeholder: andar, correr, pular
- scripts/main.gd         -> cenário de teste (chão, degraus, rampa, árvores) + contador de FPS

## Testar no PC
Abra a pasta no Godot 4.3+ (Import) e aperte F5.
WASD/setas = mover (Shift = andar), Espaço = pular, Q/E = girar câmera.
O mouse emula toque: dá para testar o analógico e a câmera clicando e arrastando.

## Testar no Android (USB)
1. Celular: ative Opções do desenvolvedor e Depuração USB; conecte o cabo e aceite a autorização.
2. Godot: Editor > Gerenciar Modelos de Exportação (instalar os da mesma versão).
3. Instale JDK 17 e o Android SDK (siga a doc oficial "Exporting for Android") e
   aponte os caminhos em Editor > Configurações do Editor > Exportar > Android.
4. Projeto > Exportar > Adicionar... > Android. Crie/aponte um debug keystore.
5. Com o celular conectado, clique no ícone de Android no topo do editor (Implantação com um clique).
   Ou exporte um APK (Debug) e instale/envie para o celular.
