extends Control
## Controles de toque com multitouch.
## - Metade esquerda da tela: analógico virtual flutuante (aparece onde você tocar).
## - Metade direita: arrastar para girar a câmera.
## - Botão "Pular" no canto inferior direito.
## Cada dedo é rastreado pelo seu índice, então andar + girar câmera + pular funcionam juntos.

const JOY_RADIUS := 120.0
const JUMP_RADIUS := 80.0

var _joy_id := -1
var _cam_id := -1
var _jump_id := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(queue_redraw)


func _screen() -> Vector2:
    return get_viewport().get_visible_rect().size


func _jump_center() -> Vector2:
    var s := _screen()
    return Vector2(s.x - 170.0, s.y - 150.0)


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var s := _screen()
        if event.pressed:
            if _jump_id == -1 and event.position.distance_to(_jump_center()) <= JUMP_RADIUS * 1.3:
                _jump_id = event.index
                Controls.queue_jump()
            elif _joy_id == -1 and event.position.x < s.x * 0.5:
                _joy_id = event.index
                _joy_origin = event.position
                _joy_pos = event.position
            elif _cam_id == -1 and event.position.x >= s.x * 0.5:
                _cam_id = event.index
        else:
            if event.index == _joy_id:
                _joy_id = -1
                Controls.touch_move = Vector2.ZERO
            elif event.index == _cam_id:
                _cam_id = -1
            elif event.index == _jump_id:
                _jump_id = -1
        queue_redraw()
    elif event is InputEventScreenDrag:
        if event.index == _joy_id:
            var d: Vector2 = event.position - _joy_origin
            if d.length() > JOY_RADIUS:
                d = d.normalized() * JOY_RADIUS
            _joy_pos = _joy_origin + d
            Controls.touch_move = d / JOY_RADIUS
        elif event.index == _cam_id:
            Controls.look_delta += event.relative
        queue_redraw()


func _draw() -> void:
    var s := _screen()
    var base := _joy_origin if _joy_id != -1 else Vector2(200.0, s.y - 170.0)
    var knob := _joy_pos if _joy_id != -1 else base
    draw_circle(base, JOY_RADIUS, Color(1, 1, 1, 0.12))
    draw_arc(base, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.4), 3.0)
    draw_circle(knob, 48.0, Color(1, 1, 1, 0.35))

    var jc := _jump_center()
    var alpha := 0.6 if _jump_id != -1 else 0.3
    draw_circle(jc, JUMP_RADIUS, Color(0.3, 0.7, 1.0, alpha))
    draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 3.0)
    draw_string(ThemeDB.fallback_font, jc + Vector2(-JUMP_RADIUS, 10.0), "Pular",
        HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 28, Color.WHITE)
