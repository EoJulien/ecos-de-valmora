extends Node3D
## Cena de teste da Etapa 1: chão, plataformas para pular, rampa, árvores,
## jogador, câmera e controles de toque. Tudo montado por código para facilitar
## a troca por cenas/modelos reais nas próximas etapas.

var _fps_label: Label


func _ready() -> void:
    _build_environment()
    _build_world()

    var player = preload("res://scripts/player.gd").new()
    add_child(player)
    player.position = Vector3(0.0, 1.0, 0.0)

    var rig = preload("res://scripts/camera_rig.gd").new()
    add_child(rig)
    rig.target = player
    rig.global_position = player.position + Vector3(0.0, 1.6, 0.0)
    player.camera_rig = rig
    rig.arm.add_excluded_object(player.get_rid())

    _build_ui()


func _process(_delta: float) -> void:
    _fps_label.text = "FPS: %d" % Engine.get_frames_per_second()


func _build_environment() -> void:
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.25, 0.5, 0.85)
    sky_mat.sky_horizon_color = Color(0.7, 0.82, 0.95)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
    sun.shadow_enabled = false  # sombras desligadas: barato para celulares modestos
    add_child(sun)


func _box(pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees = rot_deg
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    body.add_child(mi)
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    cs.shape = shape
    body.add_child(cs)
    add_child(body)


func _tree(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    add_child(body)

    var trunk := CylinderMesh.new()
    trunk.top_radius = 0.25
    trunk.bottom_radius = 0.3
    trunk.height = 2.0
    var tm := MeshInstance3D.new()
    tm.mesh = trunk
    tm.position.y = 1.0
    var tmat := StandardMaterial3D.new()
    tmat.albedo_color = Color(0.4, 0.27, 0.15)
    tm.material_override = tmat
    body.add_child(tm)

    var canopy := CylinderMesh.new()
    canopy.top_radius = 0.0
    canopy.bottom_radius = 1.4
    canopy.height = 3.0
    var cm := MeshInstance3D.new()
    cm.mesh = canopy
    cm.position.y = 3.2
    var cmat := StandardMaterial3D.new()
    cmat.albedo_color = Color(0.15, 0.5, 0.2)
    cm.material_override = cmat
    body.add_child(cm)

    var cs := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = 0.3
    shape.height = 2.0
    cs.shape = shape
    cs.position.y = 1.0
    body.add_child(cs)


func _build_world() -> void:
    _box(Vector3(0.0, -0.5, 0.0), Vector3(100.0, 1.0, 100.0), Color(0.35, 0.65, 0.3))
    # Degraus para testar o pulo (0.6 m, 1.2 m, 1.8 m)
    _box(Vector3(6.0, 0.3, -4.0), Vector3(4.0, 0.6, 4.0), Color(0.6, 0.6, 0.65))
    _box(Vector3(10.0, 0.6, -4.0), Vector3(4.0, 1.2, 4.0), Color(0.55, 0.55, 0.6))
    _box(Vector3(14.0, 0.9, -4.0), Vector3(4.0, 1.8, 4.0), Color(0.5, 0.5, 0.55))
    # Rampa
    _box(Vector3(-8.0, 0.5, -4.0), Vector3(4.0, 0.4, 8.0), Color(0.7, 0.55, 0.35), Vector3(15.0, 0.0, 0.0))
    # Árvores em anel
    for i in range(12):
        var a := TAU * float(i) / 12.0
        _tree(Vector3(cos(a) * 25.0, 0.0, sin(a) * 25.0))
    _tree(Vector3(-5.0, 0.0, 8.0))
    _tree(Vector3(4.0, 0.0, 10.0))
    _tree(Vector3(-12.0, 0.0, 6.0))


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    layer.add_child(preload("res://scripts/touch_controls.gd").new())
    _fps_label = Label.new()
    _fps_label.position = Vector2(16.0, 12.0)
    _fps_label.add_theme_color_override("font_outline_color", Color.BLACK)
    _fps_label.add_theme_constant_override("outline_size", 4)
    layer.add_child(_fps_label)
