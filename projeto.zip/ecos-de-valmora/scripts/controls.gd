extends Node
## Autoload "Controls": estado global de entrada.
## Toque (celular) alimenta touch_move / look_delta / jump.
## Teclado (PC, só para testar): WASD/setas, Shift = andar devagar, Espaço = pular, Q/E = câmera.

var touch_move := Vector2.ZERO
var look_delta := Vector2.ZERO
var _jump_queued := false


func queue_jump() -> void:
    _jump_queued = true


func consume_jump() -> bool:
    var j := _jump_queued
    _jump_queued = false
    return j


func take_look() -> Vector2:
    var l := look_delta
    look_delta = Vector2.ZERO
    return l


func get_move() -> Vector2:
    var k := Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        k.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        k.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        k.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        k.y += 1.0
    if k != Vector2.ZERO:
        k = k.normalized()
        if Input.is_key_pressed(KEY_SHIFT):
            k *= 0.4
        return k
    return touch_move


func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE:
        _jump_queued = true
