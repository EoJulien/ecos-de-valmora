extends Node3D
## Câmera em terceira pessoa. Segue o alvo, gira com arrasto de toque (ou Q/E no PC)
## e usa SpringArm3D para não atravessar paredes.

const TOUCH_SENS := 0.006
const KEY_SPEED := 2.0

var target: Node3D
var yaw := 0.0
var pitch := -0.35
var arm: SpringArm3D
var cam: Camera3D


func _ready() -> void:
    arm = SpringArm3D.new()
    arm.spring_length = 6.0
    arm.margin = 0.3
    add_child(arm)
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.far = 200.0
    arm.add_child(cam)
    cam.current = true


func _process(delta: float) -> void:
    if target == null:
        return
    global_position = global_position.lerp(
        target.global_position + Vector3(0.0, 1.6, 0.0), minf(1.0, 12.0 * delta))
    var look := Controls.take_look()
    yaw -= look.x * TOUCH_SENS
    pitch = clampf(pitch - look.y * TOUCH_SENS, -1.2, 0.1)
    if Input.is_key_pressed(KEY_Q):
        yaw += KEY_SPEED * delta
    if Input.is_key_pressed(KEY_E):
        yaw -= KEY_SPEED * delta
    rotation = Vector3(pitch, yaw, 0.0)
